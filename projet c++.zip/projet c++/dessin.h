#include <iostream>
#include <cmath>
#include "figure.h"
#include "fenetres.h"

using std::cout;
using std::endl;

class dessin {
public:
    figure tab[100];
    int count;
    fenetres f;

public:
    dessin(int c, figure t[]) {
        count = c;
        for (int i = 0; i < count; i++) {
            tab[i] = t[i];
        }
    }
    
    void dessiner() {
        for (int i = 0; i < count; i++) {
            tab[i].dessiner();
        }
    }

    void DessinerBonhomme(int x, int y, int r, int c, int h, int l, int hp, int hm, int lm) {
        figure f1, f2, f3, f4, f5, f6;

        f1.set_cercle(x, y, r, c);
        f2.set_rectangle(x - l / 2, y + r, h, l, c);
        f3.set_line(x - l / 6, y + r + h, hp, 0, c);
        f4.set_line(x + l / 6, y + r + h, hp, 0, c);
        f5.set_line(x - l / 2, y + r + h / 3, hm, -lm, c);
        f6.set_line(x + l / 2, y + r + h / 3, hm, lm, c);
    }


//hp : hauteur des bras du bonhomme.
//hm : hauteur des jambes du bonhomme.
//lm : longueur des bras et des jambes du bonhomme.
    void deplacementCirculaire(int x, int y, int r, int c, int h, int l, int hp, int hm, int lm, int x1, int y1, int r1) {
        int t = 0;
        int i = 0;
        int z=x;
        int w=y;
        DessinerBonhomme(x, y, r, c, h, l, hp, hm, lm);
        while (t == 0) {
            setactivepage(1);
            cleardevice();
            x = x1 + 300 * cos(i * M_PI / 180);
            y = y1 + 300 * sin(i * M_PI / 180);
            DessinerBonhomme(x, y, r, c, h, l, hp, hm, lm);
            i = i + 1;
            delay(1);
            
            setactivepage(0);
            cleardevice();
            x = x1 + 300 * cos(i * M_PI / 180);
            y = y1 + 300 * sin(i * M_PI / 180);
            DessinerBonhomme(x, y, r, c, h, l, hp, hm, lm);
            i = i + 1;
            delay(1);
            if (z==x & w==y){
            	break;
			}
        }
    }
    void dessinerCroix(int x, int y, int taille, int couleur) {
    figure f;
    f.set_croix(x, y, taille, couleur);
    f.dessiner();
}

    void dessinerTriangle(int x, int y, int hauteur, int base, int couleur) {
    figure f;
    f.set_triangle(x, y, hauteur, base, couleur);
    f.dessiner();
}

    void deplacerFigure(figure& f, int dx, int dy) {
    f.deplacer(dx, dy);
}

    
};

