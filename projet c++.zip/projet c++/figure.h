#include <graphics.h>
#include <math.h> 
#include <iostream>

class figure {
public:
    int type;
    int x, y, a, b, couleur;
    
    void set_line(int x, int y, int h, int l, int c) {
        setcolor(c);
        line(x, y, x + l, y + h);    
        type = 1;            
    }
    
    void set_cercle(int x, int y, int r, int c) {
        setcolor(c);
        circle(x, y, r);
        type = 2;
    }


    void set_rectangle(int x, int y, int h, int l, int c) {
        setcolor(c);
        rectangle(x, y, x + l, y + h);
        type = 3;            
    }

    
    void set_croix(int x, int y, int taille, int c) {
    int h = taille;
    int l = taille;
    set_line(x, y - h / 2, h, l, c);
    set_line(x, y + h / 2, -h, l, c);
    type = 4;
}



    void set_triangle(int x, int y, int h, int l, int c) {
        setcolor(c);
        line(x, y - 2 * h / 3, x + l / 2, y + h / 3);
        line(x + l / 2, y + h / 3, x - l / 2, y + h / 3);
        line(x - l / 2, y + h / 3, x, y - 2 * h / 3);
        type = 5;
    }

    void dessiner() {
        switch (type) {
            case 1: // droite horizontale
                setcolor(couleur);
                line(x - a/2, y, x + a/2, y);
                break;
            case 2: // cercle
                setcolor(couleur);
                circle(x, y, a/2);
                break;
            case 3: // rectangle
                setcolor(couleur);
                rectangle(x - a/2, y - b/2, x + a/2, y + b/2);
                break;
            case 4: // croix
                setcolor(couleur);
                line(x - a/2, y, x + a/2, y);
                line(x, y - b/2, x, y + b/2);
                break;
            case 5: // triangle
                setcolor(couleur);
                line(x, y - 2*b/3, x + a/2, y + b/3);
                line(x + a/2, y + b/3, x - a/2, y + b/3);
                line(x - a/2, y + b/3, x, y - 2*b/3);
                break;
            default:
                // Type de figure invalide
                break;
        }
    }

    void deplacer(int dx, int dy) {
        setcolor(getbkcolor());
        dessiner();
        x += dx;
        y += dy;
        setcolor(couleur);
        dessiner();
    }
};

