#include <iostream>
#include "fenetres.h"
#include "dessin.h"

using namespace std;

int main() {
    fenetres f;
    figure t[6];
    dessin d(6, t);
    int choix = 0;

    while (true) {
        cout << "Que d�sirez-vous ?" << endl;
        cout << "    1 - Reproduire le bonhomme sans animations" << endl;
        cout << "    2 - Reproduire le bonhomme faisant un tour" << endl;
        cout << "    3 - Dessiner une croix" << endl;
        cout << "    4 - Dessiner un triangle" << endl;
        cout << "    5 - Fermer le programme" << endl;

        cin >> choix;

        if (choix == 1) {
            f.ouvrir_graphique();
            d.DessinerBonhomme(f.get_x_max() / 2, f.get_y_max() / 3, 50, 3, 150, 100, 250, 200, 100);
            d.dessiner();
            system("pause");
            f.fermer_graphique();
        }
        else if (choix == 2) {
            f.ouvrir_graphique();
            d.deplacementCirculaire(2 * f.get_x_max() / 3, 400, 20, 3, 50, 40, 50, 80, 20, f.get_x_max() / 2, f.get_y_max() / 2, 300);
            d.dessiner();
            f.fermer_graphique();
        }
        else if (choix == 3) {
            int x, y, taille, couleur;
            cout << "Entrez les coordonn�es x et y de la croix : ";
            cin >> x >> y;
            cout << "Entrez la taille de la croix : ";
            cin >> taille;
            cout << "Entrez la couleur de la croix : ";
            cin >> couleur;

            f.ouvrir_graphique();
            d.dessinerCroix(x, y, taille, couleur);
            system("pause");
            f.fermer_graphique();
        }
        else if (choix == 4) {
            int x, y, hauteur, base, couleur;
            cout << "Entrez les coordonn�es x et y du triangle : ";
            cin >> x >> y;
            cout << "Entrez la hauteur du triangle : ";
            cin >> hauteur;
            cout << "Entrez la base du triangle : ";
            cin >> base;
            cout << "Entrez la couleur du triangle : ";
            cin >> couleur;

            f.ouvrir_graphique();
            d.dessinerTriangle(x, y, hauteur, base, couleur);
            system("pause");
            f.fermer_graphique();
        }
        else if (choix == 5) {
            break;
        }
        else {
            cout << "Commande introuvable !" << endl;
        }
    }

    return 0;
}

