#ifndef FENETRES_H
#define FENETRES_H
#include <graphics.h>
class fenetres {
	public :
		void ouvrir_graphique(){
			initwindow(getmaxwidth( ), getmaxheight( ));
		}
		void fermer_graphique(){
			closegraph(); 
		}
		int get_couleur_fond(){
			return getbkcolor();

		}
		int get_x_max(){
			return getmaxwidth( );
		}
		int get_y_max(){
			return getmaxheight( );
		}
		int get_couleur(int x,int y){
			return getpixel(x, y);
		}
		void allume(int x,int y,int c){
			putpixel( x,  y,  c);
		}
};
#endif
